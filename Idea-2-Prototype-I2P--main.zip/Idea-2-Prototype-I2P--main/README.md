
I created the quiz website from scratch, and used wix to create the portfolio building portion of the prototype.
https://jdrhymes11.wixsite.com/prototype
